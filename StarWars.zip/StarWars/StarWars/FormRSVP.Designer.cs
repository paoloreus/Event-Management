﻿namespace StarWars
{
    partial class FormRSVP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRSVP = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.txteid = new System.Windows.Forms.TextBox();
            this.txtcid = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblTicket = new System.Windows.Forms.Label();
            this.lblEvent = new System.Windows.Forms.Label();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnRSVP
            // 
            this.btnRSVP.Location = new System.Drawing.Point(66, 165);
            this.btnRSVP.Name = "btnRSVP";
            this.btnRSVP.Size = new System.Drawing.Size(126, 43);
            this.btnRSVP.TabIndex = 0;
            this.btnRSVP.Text = "RSVP for Event";
            this.btnRSVP.UseVisualStyleBackColor = true;
            this.btnRSVP.Click += new System.EventHandler(this.btnRSVP_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(198, 165);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(126, 43);
            this.btnBack.TabIndex = 1;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // txteid
            // 
            this.txteid.Location = new System.Drawing.Point(293, 31);
            this.txteid.Multiline = true;
            this.txteid.Name = "txteid";
            this.txteid.Size = new System.Drawing.Size(71, 30);
            this.txteid.TabIndex = 2;
            // 
            // txtcid
            // 
            this.txtcid.Location = new System.Drawing.Point(293, 102);
            this.txtcid.Multiline = true;
            this.txtcid.Name = "txtcid";
            this.txtcid.Size = new System.Drawing.Size(71, 30);
            this.txtcid.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 33);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter Event ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(232, 33);
            this.label2.TabIndex = 5;
            this.label2.Text = "Enter Customer ID:";
            // 
            // lblTicket
            // 
            this.lblTicket.AutoSize = true;
            this.lblTicket.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTicket.Location = new System.Drawing.Point(392, 35);
            this.lblTicket.Name = "lblTicket";
            this.lblTicket.Size = new System.Drawing.Size(101, 22);
            this.lblTicket.TabIndex = 6;
            this.lblTicket.Text = "Ticket Info:";
            // 
            // lblEvent
            // 
            this.lblEvent.AutoSize = true;
            this.lblEvent.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEvent.Location = new System.Drawing.Point(856, 35);
            this.lblEvent.Name = "lblEvent";
            this.lblEvent.Size = new System.Drawing.Size(96, 22);
            this.lblEvent.TabIndex = 7;
            this.lblEvent.Text = "Event List:";
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomer.Location = new System.Drawing.Point(508, 35);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(126, 22);
            this.lblCustomer.TabIndex = 8;
            this.lblCustomer.Text = "Customer List:";
            // 
            // formRSVP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1191, 703);
            this.Controls.Add(this.lblCustomer);
            this.Controls.Add(this.lblEvent);
            this.Controls.Add(this.lblTicket);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtcid);
            this.Controls.Add(this.txteid);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnRSVP);
            this.Name = "formRSVP";
            this.Text = "formRSVP";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.formRSVP_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRSVP;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.TextBox txteid;
        private System.Windows.Forms.TextBox txtcid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblTicket;
        private System.Windows.Forms.Label lblEvent;
        private System.Windows.Forms.Label lblCustomer;
    }
}