﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StarWars
{
    public partial class FrmCustomer : Form
    {
        Form1 page;
        formStart pageStart;
        EventCoordinator eCoord;
        int type;    //if type is 1 then source is form1, if type is 2 then source is formStart
        bool isEvent;
        public FrmCustomer()
        {
            InitializeComponent();
        }

        public FrmCustomer(Form1 f1, EventCoordinator coordinator)
        {
            eCoord = coordinator;
            page = f1;
            type = 1;
            InitializeComponent();         
        }

        public FrmCustomer(formStart s1, EventCoordinator coordinator)
        {
            InitializeComponent();
            pageStart = s1;
            eCoord = coordinator;
            type = 2;
        }
        private void FrmCustomer_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (type == 1)
            {
                this.Close();
                page.Show();
            }

            else
            {
                this.Close();
                pageStart.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int phoneNum = 0;
            if (txtFirst.Text.Length < 1 || txtLast.Text.Length < 1 || !int.TryParse(txtPhone.Text, out phoneNum))
            {
                MessageBox.Show("All fields are mandatory and Input must be valid", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                eCoord.addCustomer(txtFirst.Text, txtLast.Text, txtPhone.Text);
                MessageBox.Show("Customer Added!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (type == 1)
                {
                    this.Close();
                    page.Show();
                }
                else
                {
                    this.Close();
                    pageStart.Show();
                }
            }
        }
    }
}
