﻿namespace StarWars
{
    partial class formDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtid = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.fieldid = new System.Windows.Forms.Label();
            this.fieldName = new System.Windows.Forms.Label();
            this.lblid = new System.Windows.Forms.Label();
            this.fieldLastName = new System.Windows.Forms.Label();
            this.lblLast = new System.Windows.Forms.Label();
            this.lblFirst = new System.Windows.Forms.Label();
            this.fieldPhone = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.lblinfo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtid
            // 
            this.txtid.Location = new System.Drawing.Point(127, 35);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(93, 22);
            this.txtid.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Customer ID:";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(127, 63);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(93, 30);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // fieldid
            // 
            this.fieldid.AutoSize = true;
            this.fieldid.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fieldid.Location = new System.Drawing.Point(142, 144);
            this.fieldid.Name = "fieldid";
            this.fieldid.Size = new System.Drawing.Size(187, 36);
            this.fieldid.TabIndex = 3;
            this.fieldid.Text = "Customer ID:";
            this.fieldid.Visible = false;
            // 
            // fieldName
            // 
            this.fieldName.AutoSize = true;
            this.fieldName.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fieldName.Location = new System.Drawing.Point(142, 190);
            this.fieldName.Name = "fieldName";
            this.fieldName.Size = new System.Drawing.Size(166, 36);
            this.fieldName.TabIndex = 4;
            this.fieldName.Text = "First Name:";
            this.fieldName.Visible = false;
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblid.Location = new System.Drawing.Point(427, 144);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(44, 36);
            this.lblid.TabIndex = 5;
            this.lblid.Text = "ID";
            this.lblid.Visible = false;
            // 
            // fieldLastName
            // 
            this.fieldLastName.AutoSize = true;
            this.fieldLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fieldLastName.Location = new System.Drawing.Point(142, 237);
            this.fieldLastName.Name = "fieldLastName";
            this.fieldLastName.Size = new System.Drawing.Size(164, 36);
            this.fieldLastName.TabIndex = 6;
            this.fieldLastName.Text = "Last Name:";
            this.fieldLastName.Visible = false;
            // 
            // lblLast
            // 
            this.lblLast.AutoSize = true;
            this.lblLast.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLast.Location = new System.Drawing.Point(427, 237);
            this.lblLast.Name = "lblLast";
            this.lblLast.Size = new System.Drawing.Size(92, 36);
            this.lblLast.TabIndex = 7;
            this.lblLast.Text = "Name";
            this.lblLast.Visible = false;
            // 
            // lblFirst
            // 
            this.lblFirst.AutoSize = true;
            this.lblFirst.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirst.Location = new System.Drawing.Point(427, 190);
            this.lblFirst.Name = "lblFirst";
            this.lblFirst.Size = new System.Drawing.Size(92, 36);
            this.lblFirst.TabIndex = 8;
            this.lblFirst.Text = "Name";
            this.lblFirst.Visible = false;
            // 
            // fieldPhone
            // 
            this.fieldPhone.AutoSize = true;
            this.fieldPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fieldPhone.Location = new System.Drawing.Point(142, 282);
            this.fieldPhone.Name = "fieldPhone";
            this.fieldPhone.Size = new System.Drawing.Size(223, 36);
            this.fieldPhone.TabIndex = 9;
            this.fieldPhone.Text = "Phone Number:";
            this.fieldPhone.Visible = false;
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhone.Location = new System.Drawing.Point(427, 282);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(120, 36);
            this.lblPhone.TabIndex = 10;
            this.lblPhone.Text = "Number";
            this.lblPhone.Visible = false;
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(326, 407);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(115, 39);
            this.btnBack.TabIndex = 11;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(326, 351);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(115, 39);
            this.btnDelete.TabIndex = 12;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Visible = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // lblinfo
            // 
            this.lblinfo.AutoSize = true;
            this.lblinfo.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinfo.Location = new System.Drawing.Point(372, 35);
            this.lblinfo.Name = "lblinfo";
            this.lblinfo.Size = new System.Drawing.Size(165, 33);
            this.lblinfo.TabIndex = 13;
            this.lblinfo.Text = "Customer ID:";
            // 
            // formDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(853, 510);
            this.Controls.Add(this.lblinfo);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.fieldPhone);
            this.Controls.Add(this.lblFirst);
            this.Controls.Add(this.lblLast);
            this.Controls.Add(this.fieldLastName);
            this.Controls.Add(this.lblid);
            this.Controls.Add(this.fieldName);
            this.Controls.Add(this.fieldid);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtid);
            this.Name = "formDetails";
            this.Text = "formDetails";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.formDetails_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.formDetails_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label fieldid;
        private System.Windows.Forms.Label fieldName;
        private System.Windows.Forms.Label lblid;
        private System.Windows.Forms.Label fieldLastName;
        private System.Windows.Forms.Label lblLast;
        private System.Windows.Forms.Label lblFirst;
        private System.Windows.Forms.Label fieldPhone;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label lblinfo;
    }
}