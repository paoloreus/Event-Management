﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StarWars
{
    public partial class FormRSVP : Form
    {
        Form1 page;
        formStart pageStart;
        int type;
        EventCoordinator eCoord;
        public FormRSVP()
        {
            InitializeComponent();
        }

        public FormRSVP(Form1 f1, EventCoordinator coordinator)
        {
            page = f1;
            eCoord = coordinator;
            type = 1;
            InitializeComponent();
            

            lblTicket.Visible = false;
            lblCustomer.Text = eCoord.customerList();
            lblEvent.Text = eCoord.eventList();
        }

        public FormRSVP(formStart s1, EventCoordinator coordinator)
        {
            InitializeComponent();
            pageStart = s1;
            eCoord = coordinator;
            type = 2;

            lblTicket.Visible = false;
            lblCustomer.Text = eCoord.customerList();
            lblEvent.Text = eCoord.eventList();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            if (type == 1)
            {
                this.Close();
                page.Show();
            }
            else
            {
                this.Close();
                pageStart.Show();
            }
        }


        private void btnRSVP_Click(object sender, EventArgs e)
        {
            string info = "";
            int cid = 0;
            int eid = 0;
            if (int.TryParse(txtcid.Text, out cid) && int.TryParse(txteid.Text, out eid))
            {
                info = eCoord.register(cid, eid);
                if (info != null)
                {
                    lblCustomer.Visible = false;
                    lblEvent.Visible = false;
                    MessageBox.Show("RSVP has been successfully made!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    lblTicket.Text += info;
                    lblTicket.Visible = true;
                }

                else
                {
                    MessageBox.Show("RSVP has failed. Please make sure both ids exist");
                }
            }

            else
            {
                MessageBox.Show("Invalid search");
            }
        }

        private void formRSVP_FormClosing(object sender, FormClosingEventArgs e)
        {
           
        }
    }
}
