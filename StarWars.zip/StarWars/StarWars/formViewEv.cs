﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StarWars
{
   
    public partial class FormViewEv : Form
    {
        Form1 page;
        formStart pageStart;
        int type;
       
        public FormViewEv()
        {
            InitializeComponent();
        }

        public FormViewEv(Form1 f1, EventCoordinator coordinator)
        {
            page = f1;
            type = 1;
            display(coordinator);
            InitializeComponent();
       
        }

        public FormViewEv(formStart s1, EventCoordinator coordinator)
        {
            pageStart = s1;
            type = 2;
            display(coordinator);
            InitializeComponent();
        }

        public void display(EventCoordinator coordinator)
        {
            Label[] labels = new Label[coordinator.getNumEvents()];
            Label[] fields = new Label[coordinator.getNumEvents()];

            Event[] eventList = new Event[coordinator.getNumEvents()];
            eventList = coordinator.getEventList();

            for (int i = 0; i < coordinator.getNumEvents(); i++)
            {
                fields[i] = new Label();

                //Entire String
                fields[i].Text = eventList[i].ToString();

                fields[i].Location = new Point((70), i * 75);
                fields[i].Height = 75;
                fields[i].Font = new Font(fields[i].Font.Name, 12, fields[i].Font.Style, fields[i].Font.Unit);

                this.Controls.Add(fields[i]);
                fields[i].Show();
            }
        }

        private void btnMain_Click(object sender, EventArgs e)
        {
            if (type == 1)
            {
                this.Close();
                page.Show();
            }

            else
            {
                this.Close();
                pageStart.Show();
            }
        }
    }
}
