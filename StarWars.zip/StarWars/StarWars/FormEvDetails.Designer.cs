﻿namespace StarWars
{
    partial class FormEvDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.fieldName = new System.Windows.Forms.Label();
            this.fieldid = new System.Windows.Forms.Label();
            this.fieldDate = new System.Windows.Forms.Label();
            this.fieldVenue = new System.Windows.Forms.Label();
            this.fieldAttendees = new System.Windows.Forms.Label();
            this.fieldSpace = new System.Windows.Forms.Label();
            this.fieldBookings = new System.Windows.Forms.Label();
            this.lblVenue = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblid = new System.Windows.Forms.Label();
            this.lblSpace = new System.Windows.Forms.Label();
            this.lblAttendees = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.txtAttendees = new System.Windows.Forms.Label();
            this.lblinfo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(71, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Event ID:";
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(157, 41);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(100, 22);
            this.txtSearch.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(157, 69);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 30);
            this.button1.TabIndex = 2;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(523, 620);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(146, 39);
            this.button2.TabIndex = 3;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // fieldName
            // 
            this.fieldName.AutoSize = true;
            this.fieldName.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fieldName.Location = new System.Drawing.Point(312, 90);
            this.fieldName.Name = "fieldName";
            this.fieldName.Size = new System.Drawing.Size(157, 33);
            this.fieldName.TabIndex = 4;
            this.fieldName.Text = "Event Name:";
            this.fieldName.Visible = false;
            // 
            // fieldid
            // 
            this.fieldid.AutoSize = true;
            this.fieldid.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fieldid.Location = new System.Drawing.Point(312, 41);
            this.fieldid.Name = "fieldid";
            this.fieldid.Size = new System.Drawing.Size(121, 33);
            this.fieldid.TabIndex = 5;
            this.fieldid.Text = "Event ID:";
            this.fieldid.Visible = false;
            // 
            // fieldDate
            // 
            this.fieldDate.AutoSize = true;
            this.fieldDate.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fieldDate.Location = new System.Drawing.Point(312, 202);
            this.fieldDate.Name = "fieldDate";
            this.fieldDate.Size = new System.Drawing.Size(145, 33);
            this.fieldDate.TabIndex = 6;
            this.fieldDate.Text = "Event Date:";
            this.fieldDate.Visible = false;
            // 
            // fieldVenue
            // 
            this.fieldVenue.AutoSize = true;
            this.fieldVenue.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fieldVenue.Location = new System.Drawing.Point(312, 144);
            this.fieldVenue.Name = "fieldVenue";
            this.fieldVenue.Size = new System.Drawing.Size(161, 33);
            this.fieldVenue.TabIndex = 7;
            this.fieldVenue.Text = "Event Venue:";
            this.fieldVenue.Visible = false;
            this.fieldVenue.Click += new System.EventHandler(this.label5_Click);
            // 
            // fieldAttendees
            // 
            this.fieldAttendees.AutoSize = true;
            this.fieldAttendees.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fieldAttendees.Location = new System.Drawing.Point(312, 259);
            this.fieldAttendees.Name = "fieldAttendees";
            this.fieldAttendees.Size = new System.Drawing.Size(256, 33);
            this.fieldAttendees.TabIndex = 8;
            this.fieldAttendees.Text = "Registered Attendees:";
            this.fieldAttendees.Visible = false;
            // 
            // fieldSpace
            // 
            this.fieldSpace.AutoSize = true;
            this.fieldSpace.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fieldSpace.Location = new System.Drawing.Point(312, 315);
            this.fieldSpace.Name = "fieldSpace";
            this.fieldSpace.Size = new System.Drawing.Size(210, 33);
            this.fieldSpace.TabIndex = 9;
            this.fieldSpace.Text = "Available Spaces:";
            this.fieldSpace.Visible = false;
            // 
            // fieldBookings
            // 
            this.fieldBookings.AutoSize = true;
            this.fieldBookings.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fieldBookings.Location = new System.Drawing.Point(312, 369);
            this.fieldBookings.Name = "fieldBookings";
            this.fieldBookings.Size = new System.Drawing.Size(266, 33);
            this.fieldBookings.TabIndex = 10;
            this.fieldBookings.Text = "Customers Registered:";
            this.fieldBookings.Visible = false;
            // 
            // lblVenue
            // 
            this.lblVenue.AutoSize = true;
            this.lblVenue.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVenue.Location = new System.Drawing.Point(659, 144);
            this.lblVenue.Name = "lblVenue";
            this.lblVenue.Size = new System.Drawing.Size(84, 33);
            this.lblVenue.TabIndex = 12;
            this.lblVenue.Text = "Venue";
            this.lblVenue.Visible = false;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(659, 90);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(79, 33);
            this.lblName.TabIndex = 13;
            this.lblName.Text = "Name";
            this.lblName.Visible = false;
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblid.Location = new System.Drawing.Point(659, 44);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(43, 33);
            this.lblid.TabIndex = 14;
            this.lblid.Text = "ID";
            this.lblid.Visible = false;
            // 
            // lblSpace
            // 
            this.lblSpace.AutoSize = true;
            this.lblSpace.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpace.Location = new System.Drawing.Point(659, 315);
            this.lblSpace.Name = "lblSpace";
            this.lblSpace.Size = new System.Drawing.Size(104, 33);
            this.lblSpace.TabIndex = 15;
            this.lblSpace.Text = "Number";
            this.lblSpace.Visible = false;
            // 
            // lblAttendees
            // 
            this.lblAttendees.AutoSize = true;
            this.lblAttendees.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAttendees.Location = new System.Drawing.Point(659, 259);
            this.lblAttendees.Name = "lblAttendees";
            this.lblAttendees.Size = new System.Drawing.Size(125, 33);
            this.lblAttendees.TabIndex = 16;
            this.lblAttendees.Text = "Attendees";
            this.lblAttendees.Visible = false;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(659, 202);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(67, 33);
            this.lblDate.TabIndex = 17;
            this.lblDate.Text = "Date";
            this.lblDate.Visible = false;
            // 
            // txtAttendees
            // 
            this.txtAttendees.AutoSize = true;
            this.txtAttendees.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAttendees.Location = new System.Drawing.Point(659, 369);
            this.txtAttendees.Name = "txtAttendees";
            this.txtAttendees.Size = new System.Drawing.Size(104, 33);
            this.txtAttendees.TabIndex = 18;
            this.txtAttendees.Text = "Number";
            this.txtAttendees.Visible = false;
            // 
            // lblinfo
            // 
            this.lblinfo.AutoSize = true;
            this.lblinfo.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinfo.Location = new System.Drawing.Point(732, 41);
            this.lblinfo.Name = "lblinfo";
            this.lblinfo.Size = new System.Drawing.Size(121, 33);
            this.lblinfo.TabIndex = 19;
            this.lblinfo.Text = "Event ID:";
            // 
            // frmEvDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1139, 712);
            this.Controls.Add(this.lblinfo);
            this.Controls.Add(this.txtAttendees);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblAttendees);
            this.Controls.Add(this.lblSpace);
            this.Controls.Add(this.lblid);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblVenue);
            this.Controls.Add(this.fieldBookings);
            this.Controls.Add(this.fieldSpace);
            this.Controls.Add(this.fieldAttendees);
            this.Controls.Add(this.fieldVenue);
            this.Controls.Add(this.fieldDate);
            this.Controls.Add(this.fieldid);
            this.Controls.Add(this.fieldName);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.label1);
            this.Name = "frmEvDetails";
            this.Text = "frmEvDetails";
            this.Load += new System.EventHandler(this.frmEvDetails_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label fieldName;
        private System.Windows.Forms.Label fieldid;
        private System.Windows.Forms.Label fieldDate;
        private System.Windows.Forms.Label fieldVenue;
        private System.Windows.Forms.Label fieldAttendees;
        private System.Windows.Forms.Label fieldSpace;
        private System.Windows.Forms.Label fieldBookings;
        private System.Windows.Forms.Label lblVenue;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblid;
        private System.Windows.Forms.Label lblSpace;
        private System.Windows.Forms.Label lblAttendees;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label txtAttendees;
        private System.Windows.Forms.Label lblinfo;
    }
}