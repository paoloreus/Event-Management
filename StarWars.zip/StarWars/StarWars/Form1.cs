﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Student 1: Paolo Tous             -- 101325245
//Student 2: Robertha Alvarez Diaz  -- 101236645
//Student 3: Jai Kumar              -- 101236674
//Student 4: Kanav Bhatia           -- 101278920

namespace StarWars
{
    public partial class Form1 : Form
    {
       EventCoordinator eCoord = new EventCoordinator(200, 1000, 101, 5000);
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void addCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCustomer nForm = new FrmCustomer(this, eCoord);
            this.Hide();
            nForm.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank you for using Star Wars Management!", "Close Window", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void viewCustomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormView vForm = new FormView(this, eCoord);
            this.Hide();
            vForm.Show();
            
        }

        private void viewCustomerDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            formDetails dForm = new formDetails(this, eCoord, false);
            this.Hide();
            dForm.Show();
        }

        private void deleteCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            formDetails dForm = new formDetails(this, eCoord, true);
            this.Hide();
            dForm.Show();
        }

        private void addEventToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEvent eForm = new FormEvent(this, eCoord);
            this.Hide();
            eForm.Show();
        }

        private void viewAllEventsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormViewEv eviewForm = new FormViewEv(this, eCoord);
            this.Hide();
            eviewForm.Show();
        }

        private void viewEventDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormEvDetails evdForm = new FormEvDetails(this, eCoord);
            this.Hide();
            evdForm.Show();
        }

        private void rSVPForEventToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormRSVP frmRSVP = new FormRSVP(this, eCoord);
            this.Hide();
            frmRSVP.Show();
        }

        private void viewRSVPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormViewRSVP frmviewRSVP = new FormViewRSVP(this, eCoord);
            this.Hide();
            frmviewRSVP.Show();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            formStart frmStart = new formStart(this, eCoord);
            this.Hide();
            frmStart.Show();
        }
    }
}
