﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StarWars
{
    public partial class FormEvent : Form
    {
        Form1 page;
        formStart pageStart;
        int type;
        EventCoordinator eCoord;
        public FormEvent()
        {
            InitializeComponent();
        }

        public FormEvent(Form1 f1, EventCoordinator coordinator)
        {
            InitializeComponent();
            type = 1;
            page = f1;
            eCoord = coordinator;
        }

        public FormEvent(formStart s1, EventCoordinator coordinator)
        {
            InitializeComponent();
            type = 2;
            pageStart = s1;
            eCoord = coordinator;
            
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (type == 1)
            {
                this.Close();
                page.Show();
            }
            else
            {
                this.Close();
                pageStart.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int numAttendees = 0;
            int hour = 0;
            int minute = 0;
            if (txtName.Text.Length < 1 || txtVenue.Text.Length < 1 || !int.TryParse(txtAttendees.Text, out numAttendees) ||
                !int.TryParse(txtHour.Text, out hour) || !int.TryParse(txtMinute.Text, out minute)
                )
            {
                MessageBox.Show("Please make sure all the fields contain valid input");
            }
            else
            {
                bool isValid;
                Date mydate = new Date(datePicker.Value.Day, datePicker.Value.Month, datePicker.Value.Year,
                    Convert.ToInt32(txtHour.Text), Convert.ToInt32(txtMinute.Text));

                isValid = eCoord.addEvent(txtName.Text, txtVenue.Text, mydate, Convert.ToInt32(txtAttendees.Text));


                if (isValid)
                {
                    MessageBox.Show("Event Added!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (type == 1)
                    {
                        this.Close();
                        page.Show();
                    }
                    else
                    {
                        this.Close();
                        pageStart.Show();
                    }
                }
                else
                {
                    MessageBox.Show("Failed to add Event. \nMake sure the new event is on a different venue or day", "Error");
                }
            }
        }
    }
}
