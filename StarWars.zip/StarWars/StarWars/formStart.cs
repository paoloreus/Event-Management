﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StarWars
{
    public partial class formStart : Form
    {
        Form1 page;
        EventCoordinator eCoord;
        public formStart()
        {
            InitializeComponent();
        }

        public formStart(Form1 f1, EventCoordinator coordinator)
        {
            InitializeComponent();
            page = f1;
            eCoord = coordinator;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
            page.Show();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            FrmCustomer nForm = new FrmCustomer(this, eCoord);
            this.Hide();
            nForm.Show();
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            FormView vForm = new FormView(this, eCoord);
            this.Hide();
            vForm.Show();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            formDetails dForm = new formDetails(this, eCoord, false);
            this.Hide();
            dForm.Show();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            formDetails dForm = new formDetails(this, eCoord, true);
            this.Hide();
            dForm.Show();
        }

        private void btnAddEv_Click(object sender, EventArgs e)
        {
            FormEvent eForm = new FormEvent(this, eCoord);
            this.Hide();
            eForm.Show();
        }

        private void btnViewAllEvs_Click(object sender, EventArgs e)
        {
            FormViewEv eviewForm = new FormViewEv(this, eCoord);
            this.Hide();
            eviewForm.Show();
        }

        private void btnViewEv_Click(object sender, EventArgs e)
        {
            FormEvDetails evdForm = new FormEvDetails(this, eCoord);
            this.Hide();
            evdForm.Show();
        }

        private void btnRSVP_Click(object sender, EventArgs e)
        {
            FormRSVP frmRSVP = new FormRSVP(this, eCoord);
            this.Hide();
            frmRSVP.Show();
        }

        private void btnViewRSVP_Click(object sender, EventArgs e)
        {
            FormViewRSVP frmviewRSVP = new FormViewRSVP(this, eCoord);
            this.Hide();
            frmviewRSVP.Show();
        }
    }
}
