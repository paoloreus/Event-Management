﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StarWars
{
    public partial class formDetails : Form
    {
        Form1 page;
        formStart pageStart;
        int type;
        EventCoordinator eCoord;
        bool canDelete;
        Customer c;
        public formDetails()
        {
            InitializeComponent();
        }

        public formDetails(Form1 f1, EventCoordinator coordinator, bool isDeletable)
        {
            page = f1;
            eCoord = coordinator;
            canDelete = isDeletable;
            InitializeComponent();
            type = 1;

            lblinfo.Text = coordinator.customerList();
         
        }

        public formDetails(formStart s1, EventCoordinator coordinator, bool isDeletable)
        {
            InitializeComponent();
            pageStart = s1;
            eCoord = coordinator;
            canDelete = isDeletable;
            type = 2;

            lblinfo.Text = coordinator.customerList();
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {
            
            

            if (txtid.Text.Length > 0)
            {
                int id = 0;
                if (int.TryParse(txtid.Text, out id))
                {
                  c = eCoord.findCustomer(id);
                }
                if (c != null)
                {
                    lblinfo.Visible = false;

                    lblid.Text = c.getId().ToString();
                    lblid.Visible = true;
                    fieldid.Visible = true;

                    lblFirst.Text = c.getFirstName();
                    lblFirst.Visible = true;
                    fieldName.Visible = true;

                    lblLast.Text = c.getLastName();
                    lblLast.Visible = true;
                    fieldLastName.Visible = true;

                    lblPhone.Text = c.getPhone().ToString();
                    lblPhone.Visible = true;
                    fieldPhone.Visible = true;

                    btnDelete.Visible = canDelete;
                }

                else
                {
                    MessageBox.Show("Customer Not Found!");
                }

            }

            else
            {
                MessageBox.Show("Field is empty.\nPlease insert the Customer ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            if (type == 1)
            {
                this.Close();
                page.Show();
            }

            else
            {
                this.Close();
                pageStart.Show();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            eCoord.deleteCustomer(Convert.ToInt32(txtid.Text));
            MessageBox.Show("Customer Deleted!");
            if (type == 1)
            {
                this.Close();
                page.Show();
            }
            else
            {
                this.Close();
                pageStart.Show();
            }
        }

        private void formDetails_FormClosed(object sender, FormClosedEventArgs e)
        {
            
        }

        private void formDetails_FormClosing(object sender, FormClosingEventArgs e)
        {
           
        }
    }
}
