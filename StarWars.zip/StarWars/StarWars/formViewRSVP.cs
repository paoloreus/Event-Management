﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StarWars
{
    public partial class FormViewRSVP : Form
    {
        Form1 page;
        formStart pageStart;
        int type;
        EventCoordinator eCoord;
        public FormViewRSVP()
        {
            InitializeComponent();
        }

        public FormViewRSVP(Form1 f1, EventCoordinator coordinator)
        {
            InitializeComponent();
            type = 1;
            page = f1;
            eCoord = coordinator;
            lblinfo.Text = eCoord.viewRegs();
            lblinfo.Visible = true;
        }

        public FormViewRSVP(formStart s1, EventCoordinator coordinator)
        {
            InitializeComponent();
            type = 2;
            pageStart = s1;
            eCoord = coordinator;
            lblinfo.Text = eCoord.viewRegs();
            lblinfo.Visible = true;
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            if (type == 1)
            {
                this.Close();
                page.Show();
            }
            else
            {
                this.Close();
                pageStart.Show();
            }
        }
    }
}
