﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StarWars
{
    public partial class FormView : Form
    {
        EventCoordinator eCoord;
        Form1 page;
        formStart pageStart;
        int type;
        CustomerManager cm;
        int x = 0;
        int y = 18;

        public FormView()
        {
            InitializeComponent();
        }

        public FormView(Form1 f1, EventCoordinator coordinator)
        {
            page = f1;
            type = 1;
            InitializeComponent();
            display(coordinator);
            
          
            
        }

        public FormView(formStart s1, EventCoordinator coordinator)
        {
            InitializeComponent();
            pageStart = s1;
            type = 2;
            display(coordinator);
            
        }

        public void display( EventCoordinator coordinator)
        {
            Label[] labels = new Label[coordinator.getNumCustomers()];
            Label[] fields = new Label[coordinator.getNumCustomers()];

            Customer[] customerList = new Customer[coordinator.getNumCustomers()];
            customerList = coordinator.getCustomerList();

            for (int i = 0; i < coordinator.getNumCustomers(); i++)
            {

                fields[i] = new Label();


                //Entire string
                fields[i].Text = customerList[i].ToString();

                //Just ID
                // fields[i].Text = "ID: " + customerList[i].getId();

                fields[i].Location = new Point((70), i * 75);
                fields[i].Height = 75;
                fields[i].Font = new Font(fields[i].Font.Name, 12, fields[i].Font.Style, fields[i].Font.Unit);

                this.Controls.Add(fields[i]);
                fields[i].Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (type == 1)
            {
                this.Close();
                page.Show();
            }

            else
            {
                this.Close();
                pageStart.Show();
            }
            
        }
    }
}
