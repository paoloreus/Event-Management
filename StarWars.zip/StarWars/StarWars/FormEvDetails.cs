﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StarWars
{
    public partial class FormEvDetails : Form
    {
        Form1 page;
        formStart pageStart;
        int type;
        EventCoordinator eCoord;
        Event ev;
        public FormEvDetails()
        {
            InitializeComponent();
        }

        public FormEvDetails(Form1 f1, EventCoordinator coordinator)
        {
            InitializeComponent();
            page = f1;
            eCoord = coordinator;
            type = 1;

            lblinfo.Text = coordinator.eventList();
        }

        public FormEvDetails(formStart s1, EventCoordinator coordinator)
        {
            InitializeComponent();
            pageStart = s1;
            eCoord = coordinator;
            type = 2;

            lblinfo.Text = coordinator.eventList();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (type == 1)
            {
                this.Close();
                page.Show();
            }

            else
            {
                this.Close();
                pageStart.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           

            if (txtSearch.Text.Length > 0)
            {
                int id = 0;
                if (int.TryParse(txtSearch.Text, out id))
                {
                    ev = eCoord.findEvent(id);
                }
                

                if (ev != null)
                {
                    lblinfo.Visible = false;

                    lblid.Text = ev.getEventId().ToString();
                    lblid.Visible = true;
                    fieldid.Visible = true;

                    lblName.Text = ev.getEventName();
                    lblName.Visible = true;
                    fieldName.Visible = true;

                    lblVenue.Text = ev.getVenue();
                    lblVenue.Visible = true;
                    fieldVenue.Visible = true;

                    lblDate.Text = ev.getEventMonth() + "/" + ev.getEventDay() + ", " + ev.getEventYear();
                    lblDate.Visible = true;
                    fieldDate.Visible = true;

                    lblAttendees.Text = ev.getNumAttendees().ToString();
                    lblAttendees.Visible = true;
                    fieldAttendees.Visible = true;

                    lblSpace.Text = (ev.getMaxAttendees() - ev.getNumAttendees()).ToString();
                    lblSpace.Visible = true;
                    fieldSpace.Visible = true;

                    txtAttendees.Text = ev.getAttendees();
                    txtAttendees.Visible = true;
                    fieldBookings.Visible = true;
                }


                else
                {
                    MessageBox.Show("Event Not Found!");
                }
            }

            else
            {
                MessageBox.Show("Field is Empty.\nPlease insert the Event ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void frmEvDetails_Load(object sender, EventArgs e)
        {

        }
    }
}
